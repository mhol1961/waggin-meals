# GHL Webchat + AI
1) In GHL Location: Sites → Chat Widget → Enable Webchat (and AI, if available)
2) Add FAQs & URLs (wagginmeals.com initially)
3) Copy the widget script and paste into your Next.js layout (client area) or into the HeroAssistant.

**HeroAssistant** pattern is in your codebase; drop the script when `open === true` or mount globally.

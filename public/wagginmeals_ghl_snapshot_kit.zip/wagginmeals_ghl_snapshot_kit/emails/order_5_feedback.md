---
subject: How’s {{wm_dog_name}} Loving It?
---

We hope mealtime is tail‑wagging fun!

Would you share how it’s going? A quick review helps other pet parents.
[Leave a Review](https://example.com/review)

As a thank you, enjoy **10% off** your next order: **THANKYOU10**
— Waggin Meals

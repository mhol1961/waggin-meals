---
subject: {{wm_dog_name}}’s Next Box Ships in 7 Days
---

Friendly reminder—your next subscription renews in 7 days.

Want to add treats or adjust portions?
Manage here: {{manage_subscription_url}}

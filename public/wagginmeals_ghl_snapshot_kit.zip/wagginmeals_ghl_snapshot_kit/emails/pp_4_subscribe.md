---
subject: Subscribe & Save 15%
---

Lock in savings and convenience. Flexible scheduling, easy skips.

Start a subscription: https://wagginmeals.com/subscribe

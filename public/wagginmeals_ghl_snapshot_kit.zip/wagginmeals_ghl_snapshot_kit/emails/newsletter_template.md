---
subject: {{issue_title}} — Waggin Meals Weekly
---

Hi {{contact.first_name}},
{{issue_intro}}

**This week:** {{bullet_1}}, {{bullet_2}}, {{bullet_3}}.

Until next time!

---
subject: Subscription Renewed—Next Box Coming Soon
---

Billing successful! We’ll ship your next box shortly.
Receipt is in your account portal.

— Waggin Meals

---
subject: We’re Making Fresh Food for {{wm_dog_name}}
---

Kitchen is busy! Here’s what to expect next:
- Fresh preparation and packing
- Temperature-safe shipping
- Tracking details in your next email

Thanks for trusting us with {{wm_dog_name}}’s nutrition.
— Waggin Meals

---
subject: You're Now Part of the Waggin Meals Family! 🐾
---

Welcome aboard! Your subscription details:
- **Frequency:** {{wm_subscription_frequency}}
- **Next billing:** {{wm_subscription_next_billing}}

Manage anytime: {{manage_subscription_url}}
— Waggin Meals

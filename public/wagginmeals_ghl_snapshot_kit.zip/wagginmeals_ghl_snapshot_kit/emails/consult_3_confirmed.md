---
subject: Your Consultation Is Scheduled—What to Prepare
---

Appointment: {{wm_consultation_date}}

Please have: vet records, current diet, symptoms & goals.
Your Zoom/FaceTime details are in the calendar invite.

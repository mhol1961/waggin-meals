---
subject: 50% Off Shipping—Just for You
---

Hi {{contact.first_name}},

Still thinking it over? We'd love for {{wm_dog_name}} to try Waggin Meals.
As a first-time customer, enjoy **50% off shipping**—automatically applied at checkout.

**Restore your cart:** {{cart.cartUrl}}
— Waggin Meals

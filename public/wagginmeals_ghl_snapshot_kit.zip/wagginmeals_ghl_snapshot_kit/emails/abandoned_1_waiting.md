---
subject: Your Fresh Dog Food is Waiting 🐾
---

Hey {{contact.first_name}},

You left a few yummy things in your cart for {{wm_dog_name}}. Your selections are still saved.

**Return to cart:** {{cart.cartUrl}}

If you have any questions, reply to this email—we're here to help.
— Waggin Meals

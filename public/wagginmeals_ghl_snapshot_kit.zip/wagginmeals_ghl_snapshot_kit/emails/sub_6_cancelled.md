---
subject: We’re Sorry to See You Go—Here’s 20% Off
---

If we can improve anything, we’d love your feedback.

Here’s **20% off** your next order should you return: **COME-BACK20**
— Waggin Meals

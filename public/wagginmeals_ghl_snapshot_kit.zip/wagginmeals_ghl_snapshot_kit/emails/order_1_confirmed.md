---
subject: We Got Your Order! #{{wm_last_order_number}}
---

Hi {{contact.first_name}},

Thanks for your order **#{{wm_last_order_number}}**. We’re preparing everything fresh.

**Order total:** ${{wm_last_order_amount}}
**Estimate:** {{order.estimatedDelivery}}

We’ll email updates as your order moves.
— Waggin Meals

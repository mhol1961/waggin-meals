---
subject: Let’s Create a Custom Nutrition Plan for {{wm_dog_name}}
---

Christie will review your pet’s history and goals.
Book your **$395** consultation here:
{{consult_calendar_url}}

Questions? Reply to this email.
— Waggin Meals

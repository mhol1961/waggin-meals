---
subject: Oops! We Couldn't Process Your Payment
---

We couldn’t process your subscription payment for {{wm_dog_name}}.

Please update your payment method to avoid interruption:
{{update_payment_url}}

We’ll retry automatically over the next few days.
— Waggin Meals

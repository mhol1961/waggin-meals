---
subject: {{wm_dog_name}}’s Food Arrives Today! 🎉
---

Heads up! Your package is out for delivery today.

Please refrigerate upon arrival. Check our quick storage & portioning tips inside.
— Waggin Meals

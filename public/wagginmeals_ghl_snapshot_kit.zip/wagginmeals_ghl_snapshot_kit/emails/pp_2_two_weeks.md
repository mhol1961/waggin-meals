---
subject: See the Difference in Two Weeks
---

Look for positive changes: shiny coat, steady energy, happy digestion.

Tell us how it’s going—photos welcome!

---
subject: Quick Tips for Keeping Food Fresh
---

Best practices:
- Refrigerate upon arrival
- Portion by weight and activity
- Freeze extras as needed

Questions? Reply any time.
— Waggin Meals

---
subject: Your Order Is On the Way! 📦
---

Great news—your order just shipped.

**Carrier:** {{order.carrier}}
**Tracking #:** {{order.trackingNumber}}
**Track package:** {{order.trackingUrl}}

We’ll send a reminder when it’s out for delivery.
— Waggin Meals

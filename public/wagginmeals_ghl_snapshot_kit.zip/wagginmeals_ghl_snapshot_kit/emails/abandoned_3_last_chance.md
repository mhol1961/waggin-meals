---
subject: We’ll Save Your Cart 24 More Hours
---

Hey {{contact.first_name}},

Last call to grab your saved items for {{wm_dog_name}}. We’ll keep your cart reserved for 24 more hours.

**Complete checkout:** {{cart.cartUrl}}
— Waggin Meals

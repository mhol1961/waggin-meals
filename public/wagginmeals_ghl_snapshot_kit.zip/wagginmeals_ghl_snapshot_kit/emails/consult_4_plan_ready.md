---
subject: {{wm_dog_name}}’s Personalized Nutrition Plan
---

Attached: your custom plan.
Recommended products included—add to cart with one click.

We’re here for follow‑ups any time.
— Waggin Meals

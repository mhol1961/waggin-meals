# Product Review Form (GHL Form)
Fields:
- Overall Rating (1-5)
- Dog's Name
- Product Purchased
- What did you love most? (textarea)
- Any suggestions? (textarea)
- May we share your review? (checkbox)
- Upload dog photo (file)

Automation:
- If rating ≥ 4: send Google/Facebook review request
- If rating ≤ 3: tag for CS follow-up

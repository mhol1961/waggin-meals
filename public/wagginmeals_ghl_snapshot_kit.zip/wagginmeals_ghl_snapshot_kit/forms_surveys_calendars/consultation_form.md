# Consultation Inquiry Form (GHL Form)
Fields:
- First Name* / Last Name*
- Email* / Phone*
- Dog's Name*
- Dog's Breed (optional)
- Dog's Age (number)
- Dog's Weight (number)
- Current Health Concerns (textarea)
- Consultation Type: Initial ($395) or Follow-Up
- Preferred Contact: Email / Phone / Text

Automation:
- Tag: consultation-inquiry
- Pipeline: Consultations → Inquiry
- Email: consult_1_invite

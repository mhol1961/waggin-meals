# Calendars
Appointment Types:
1) Initial Consultation — 60m — $395
2) Follow-Up — 30m — $150

Channels: Phone / Zoom / FaceTime
Reminders: 24h + 1h before
Intake: Dog name/breed/age/weight, current diet, concerns, optional vet-record upload
